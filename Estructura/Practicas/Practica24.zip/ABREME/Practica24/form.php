<?php 
    echo "<center><h1>Hola ".$_GET['nombre']." tienes ".$_GET['edad']." anios</h1></center>";
?>